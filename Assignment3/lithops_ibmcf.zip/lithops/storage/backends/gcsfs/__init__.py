from .gcsfs import GcsfsStorageBackend as StorageBackend
