from .storage import InternalStorage
from .storage import Storage
